#!/bin/bash
set -e
echo "===================================="
echo "  小小榆 Web 部署脚本"
echo "===================================="

# 检查 Node.js
if ! command -v node &> /dev/null; then
    echo "安装 Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi

NODE_VER=$(node -v)
echo "Node.js: $NODE_VER"

# 进入项目目录
cd "$(dirname "$0")"

# 安装依赖（仅生产）
echo "安装依赖..."
npm install --omit=dev 2>&1 | tail -3

# 创建数据目录
mkdir -p data

# 设置环境变量
export PORT=${PORT:-3000}
export NODE_ENV=production
export DATA_DIR=$(pwd)/data
export DB_PATH=$(pwd)/data/ai-chat.db

echo "端口: $PORT"
echo "数据库: $DB_PATH"

# 启动
echo "启动服务器..."
node dist/server/server/index.js
