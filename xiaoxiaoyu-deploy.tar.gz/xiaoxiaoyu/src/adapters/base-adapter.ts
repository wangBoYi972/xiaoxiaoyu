import type { UnifiedMessage, UnifiedStreamChunk, ChatRequestOptions, ModelInfo, ProviderConfig } from './types';

/**
 * 模型适配器抽象基类
 * 所有模型提供商适配器都继承此类
 */
export abstract class BaseModelAdapter {
  protected config: ProviderConfig;

  constructor(config: ProviderConfig) {
    this.config = config;
  }

  /** 验证 API Key/连接是否有效 */
  abstract validateApiKey(): Promise<boolean>;

  /** 获取可用模型列表 */
  abstract listModels(): Promise<ModelInfo[]>;

  /** 发送聊天请求，返回流式响应生成器 */
  abstract chat(options: ChatRequestOptions): AsyncGenerator<UnifiedStreamChunk>;

  /** 获取提供商 ID */
  get providerId(): string {
    return this.config.id;
  }

  /** 获取提供商名称 */
  get providerName(): string {
    return this.config.name;
  }

  /** 构建通用 HTTP 请求头 */
  protected buildHeaders(): Record<string, string> {
    return {
      'Content-Type': 'application/json',
      ...this.config.extraHeaders,
    };
  }

  /** 辅助方法：POST 请求并返回 Response */
  protected async fetchStream(url: string, body: unknown, signal?: AbortSignal): Promise<Response> {
    const response = await fetch(url, {
      method: 'POST',
      headers: this.buildHeaders(),
      body: JSON.stringify(body),
      signal,
    });
    if (!response.ok) {
      const errText = await response.text().catch(() => '未知错误');
      throw new Error(`[${response.status}] ${errText}`);
    }
    return response;
  }

  /** 辅助方法：读取 SSE 流 */
  protected async *readSSEStream(response: Response): AsyncGenerator<string> {
    const reader = response.body?.getReader();
    if (!reader) throw new Error('无法读取响应流');

    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.startsWith('data: ')) {
          const data = trimmed.slice(6);
          if (data === '[DONE]') return;
          yield data;
        }
      }
    }
  }

  /** 辅助方法：将 OpenAI 格式消息转为统一格式 */
  protected toOpenAIMessages(messages: UnifiedMessage[]): Array<{ role: string; content: unknown }> {
    return messages.map((msg) => ({
      role: msg.role,
      content: msg.content,
    }));
  }
}
