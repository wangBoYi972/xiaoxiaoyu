import { BaseModelAdapter } from './base-adapter';
import type { UnifiedStreamChunk, ChatRequestOptions, ModelInfo, ProviderConfig } from './types';

/**
 * OpenAI 兼容适配器基类
 * 适用于所有兼容 OpenAI Chat Completions API 的提供商
 * 包括：OpenAI、DeepSeek、通义千问、智谱GLM、Moonshot(Kimi) 等
 */
export class OpenAICompatAdapter extends BaseModelAdapter {
  private defaultModels: ModelInfo[];
  private defaultBaseUrl: string;

  constructor(config: ProviderConfig, defaultBaseUrl: string, defaultModels: ModelInfo[]) {
    super(config);
    this.defaultBaseUrl = defaultBaseUrl;
    this.defaultModels = defaultModels;
  }

  get baseUrl(): string {
    return this.config.baseUrl || this.defaultBaseUrl;
  }

  protected buildHeaders(): Record<string, string> {
    return {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${this.config.apiKey}`,
      ...this.config.extraHeaders,
    };
  }

  async validateApiKey(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/models`, {
        headers: this.buildHeaders(),
      });
      return response.ok;
    } catch {
      return false;
    }
  }

  async listModels(): Promise<ModelInfo[]> {
    try {
      const response = await fetch(`${this.baseUrl}/models`, {
        headers: this.buildHeaders(),
      });
      if (response.ok) {
        const data = await response.json() as { data?: Array<{ id: string }> };
        if (data.data) {
          return data.data.map((m) => ({
            id: m.id,
            displayName: m.id,
            provider: this.providerId,
            maxTokens: 128000,
            supportsVision: m.id.toLowerCase().includes('vision') || m.id.toLowerCase().includes('gpt-4o'),
            supportsThinking: m.id.toLowerCase().includes('o1') || m.id.toLowerCase().includes('o3'),
          }));
        }
      }
    } catch {
      // 获取模型失败，返回默认列表
    }
    return this.defaultModels;
  }

  async *chat(options: ChatRequestOptions): AsyncGenerator<UnifiedStreamChunk> {
    const body = {
      model: options.model,
      messages: this.buildMessages(options),
      temperature: options.temperature ?? 0.7,
      max_tokens: options.maxTokens ?? 4096,
      stream: true,
      stream_options: { include_usage: true },
    };

    // 如果有工具定义，添加 tools
    if (options.tools && options.tools.length > 0) {
      (body as any).tools = options.tools.map((t) => ({
        type: 'function',
        function: {
          name: t.name,
          description: t.description,
          parameters: t.parameters,
        },
      }));
    }

    try {
      const response = await this.fetchStream(
        `${this.baseUrl}/chat/completions`,
        body,
        options.signal
      );

      for await (const data of this.readSSEStream(response)) {
        if (options.signal?.aborted) break;

        try {
          const parsed = JSON.parse(data);
          const choice = parsed.choices?.[0];

          if (!choice) continue;

          // 处理 delta 内容
          const delta = choice.delta;
          if (delta?.content) {
            yield { type: 'text-delta', textDelta: delta.content };
          }

          // 处理 tool calls
          if (delta?.tool_calls) {
            for (const tc of delta.tool_calls) {
              yield {
                type: 'tool-call',
                toolCall: {
                  id: tc.id || '',
                  name: tc.function?.name || '',
                  arguments: tc.function?.arguments || '',
                },
              };
            }
          }

          // 处理结束
          if (choice.finish_reason) {
            const usage = parsed.usage;
            yield {
              type: 'done',
              doneReason: choice.finish_reason === 'stop' ? 'stop' : 'length',
              usage: usage ? { inputTokens: usage.prompt_tokens, outputTokens: usage.completion_tokens } : undefined,
            };
            return;
          }
        } catch {
          // 跳过解析失败的行
        }
      }

      // 流结束但没有 finish_reason
      yield { type: 'done', doneReason: 'stop' };
    } catch (error) {
      if ((error as Error).name === 'AbortError') {
        yield { type: 'done', doneReason: 'stop' };
        return;
      }
      yield {
        type: 'error',
        error: { message: (error as Error).message, code: 'API_ERROR' },
      };
    }
  }

  private buildMessages(options: ChatRequestOptions): Array<{ role: string; content: unknown }> {
    const messages: Array<{ role: string; content: unknown }> = [];

    if (options.systemPrompt) {
      messages.push({ role: 'system', content: options.systemPrompt });
    }

    for (const msg of options.messages) {
      messages.push({ role: msg.role, content: msg.content });
    }

    return messages;
  }
}

// 预定义的各提供商默认配置

export const OPENAI_MODELS: ModelInfo[] = [
  { id: 'gpt-4o', displayName: 'GPT-4o', provider: 'openai', maxTokens: 128000, supportsVision: true, supportsThinking: false },
  { id: 'gpt-4o-mini', displayName: 'GPT-4o Mini', provider: 'openai', maxTokens: 128000, supportsVision: true, supportsThinking: false },
  { id: 'gpt-4.1', displayName: 'GPT-4.1', provider: 'openai', maxTokens: 1048576, supportsVision: true, supportsThinking: false },
  { id: 'gpt-4.1-mini', displayName: 'GPT-4.1 Mini', provider: 'openai', maxTokens: 1048576, supportsVision: true, supportsThinking: false },
  { id: 'o3', displayName: 'o3', provider: 'openai', maxTokens: 200000, supportsVision: true, supportsThinking: true },
  { id: 'o4-mini', displayName: 'o4-mini', provider: 'openai', maxTokens: 200000, supportsVision: true, supportsThinking: true },
  { id: 'o1', displayName: 'o1', provider: 'openai', maxTokens: 200000, supportsVision: true, supportsThinking: true },
];

export const DEEPSEEK_MODELS: ModelInfo[] = [
  { id: 'deepseek-chat', displayName: 'DeepSeek-V4 Pro (最新旗舰)', provider: 'deepseek', maxTokens: 131072, supportsVision: true, supportsThinking: true },
  { id: 'deepseek-reasoner', displayName: 'DeepSeek-R1-0528 (推理)', provider: 'deepseek', maxTokens: 65536, supportsVision: false, supportsThinking: true },
  { id: 'deepseek-v3-0324', displayName: 'DeepSeek-V3-0324', provider: 'deepseek', maxTokens: 65536, supportsVision: false, supportsThinking: false },
];

export const QWEN_MODELS: ModelInfo[] = [
  { id: 'qwen3-max', displayName: '通义千问3-Max (最新)', provider: 'qwen', maxTokens: 131072, supportsVision: true, supportsThinking: true },
  { id: 'qwen3-plus', displayName: '通义千问3-Plus', provider: 'qwen', maxTokens: 131072, supportsVision: true, supportsThinking: false },
  { id: 'qwen-max', displayName: '通义千问2.5-Max', provider: 'qwen', maxTokens: 32768, supportsVision: true, supportsThinking: false },
  { id: 'qwen-plus', displayName: '通义千问2.5-Plus', provider: 'qwen', maxTokens: 131072, supportsVision: true, supportsThinking: false },
  { id: 'qwen-turbo', displayName: '通义千问-Turbo', provider: 'qwen', maxTokens: 131072, supportsVision: false, supportsThinking: false },
];

export const GLM_MODELS: ModelInfo[] = [
  { id: 'glm-4.5', displayName: 'GLM-4.5 (最新)', provider: 'glm', maxTokens: 128000, supportsVision: true, supportsThinking: true },
  { id: 'glm-4-plus', displayName: 'GLM-4-Plus', provider: 'glm', maxTokens: 128000, supportsVision: true, supportsThinking: false },
  { id: 'glm-4-flash', displayName: 'GLM-4-Flash (免费)', provider: 'glm', maxTokens: 128000, supportsVision: true, supportsThinking: false },
];

export const MOONSHOT_MODELS: ModelInfo[] = [
  { id: 'moonshot-v1-8k', displayName: 'Kimi 8K', provider: 'moonshot', maxTokens: 8192, supportsVision: false, supportsThinking: false },
  { id: 'moonshot-v1-32k', displayName: 'Kimi 32K', provider: 'moonshot', maxTokens: 32768, supportsVision: false, supportsThinking: false },
  { id: 'moonshot-v1-128k', displayName: 'Kimi 128K', provider: 'moonshot', maxTokens: 131072, supportsVision: false, supportsThinking: false },
  { id: 'kimi-latest', displayName: 'Kimi Latest (最新)', provider: 'moonshot', maxTokens: 131072, supportsVision: false, supportsThinking: false },
];
