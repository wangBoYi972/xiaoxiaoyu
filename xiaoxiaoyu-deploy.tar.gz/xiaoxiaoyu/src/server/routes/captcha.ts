// 验证码路由 — 数学表达式验证码
import { Router, Request, Response } from 'express';
import svgCaptcha from 'svg-captcha';

const captchaStore = new Map<string, { answer: string; expires: number }>();

setInterval(() => {
  const now = Date.now();
  for (const [key, val] of captchaStore) {
    if (val.expires < now) captchaStore.delete(key);
  }
}, 300000);

export function captchaRoutes(): Router {
  const router = Router();

  router.get('/', (_req: Request, res: Response) => {
    const captcha = svgCaptcha.createMathExpr({
      mathMin: 1,
      mathMax: 20,
      mathOperator: '+',
    });

    const key = Math.random().toString(36).substring(2, 15);
    captchaStore.set(key, {
      answer: captcha.text,
      expires: Date.now() + 5 * 60 * 1000,
    });

    // 直接返回 SVG 字符串（前端用 dangerouslySetInnerHTML 渲染）
    res.json({ key, svg: captcha.data });
  });

  return router;
}

export function verifyCaptcha(key: string, code: string): boolean {
  const entry = captchaStore.get(key);
  if (!entry) return false;
  if (entry.expires < Date.now()) { captchaStore.delete(key); return false; }
  return String(code).trim() === entry.answer;
}
