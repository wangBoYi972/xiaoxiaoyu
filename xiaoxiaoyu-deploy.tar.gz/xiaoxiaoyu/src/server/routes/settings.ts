// 设置管理路由
import { Router, Request, Response } from 'express';
import { authMiddleware } from '../middleware/auth';
import { queryAll, queryOne, execute } from '../store/database';

export function settingsRoutes(): Router {
  const router = Router();
  router.use(authMiddleware);

  // GET /api/settings — 获取所有设置
  router.get('/', (_req: Request, res: Response) => {
    const rows = queryAll('SELECT key, value FROM settings');
    const settings: Record<string, string> = {};
    for (const row of rows) {
      // 不暴露敏感 key
      if (row.key !== 'jwt_secret' && row.key !== 'admin_token') {
        settings[row.key] = row.value;
      }
    }
    res.json(settings);
  });

  // GET /api/settings/:key — 获取单个设置
  router.get('/:key', (req: Request, res: Response) => {
    const row = queryOne('SELECT value FROM settings WHERE key = ?', [req.params.key]);
    res.json({ value: row?.value || null });
  });

  // PUT /api/settings/:key — 设置
  router.put('/:key', (req: Request, res: Response) => {
    const { value } = req.body;
    if (value === undefined) {
      res.status(400).json({ error: '缺少 value' });
      return;
    }
    execute('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', [req.params.key, value]);
    res.json({ ok: true });
  });

  return router;
}
