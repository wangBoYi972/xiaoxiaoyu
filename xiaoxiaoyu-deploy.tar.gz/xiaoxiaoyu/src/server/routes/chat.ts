// 聊天路由 — SSE 流式响应
// 复用 src/adapters/ 中的 ModelRouter（100% Electron-free）
import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { ModelRouter } from '../../adapters/index';
import { authMiddleware, getUserId } from '../middleware/auth';
import { queryAll, queryOne, execute, executeBatch, getDatabase, saveDatabase } from '../store/database';
import { decryptApiKey } from '../store/crypto';
import { logger } from '../utils/logger';

const modelRouter = new ModelRouter();
const activeRequests = new Map<string, AbortController>();

// Token 估算
function estimateTokens(text: string | any[]): number {
  if (Array.isArray(text)) {
    return text.reduce((sum: number, p: any) => sum + (typeof p === 'string' ? p.length : JSON.stringify(p).length) / 3, 0);
  }
  return Math.ceil((typeof text === 'string' ? text.length : 0) / 3);
}

// 上下文裁剪
function trimMessages(messages: any[], maxTokens: number = 80000): any[] {
  const systemMsgs = messages.filter((m: any) => m.role === 'system');
  const otherMsgs = messages.filter((m: any) => m.role !== 'system');

  let total = systemMsgs.reduce((s: number, m: any) => s + estimateTokens(m.content), 0);
  const kept: any[] = [];

  for (let i = otherMsgs.length - 1; i >= 0; i--) {
    const tok = estimateTokens(otherMsgs[i].content);
    if (total + tok > maxTokens && kept.length >= 4) break;
    total += tok;
    kept.unshift(otherMsgs[i]);
  }

  logger.info(`上下文裁剪: ${messages.length} → ${systemMsgs.length + kept.length} 条, ~${Math.round(total)} tokens`);
  return [...systemMsgs, ...kept];
}

// 加载提供商配置（按用户过滤）
function loadProviderConfig(providerId: string, userId: number): { apiKey: string; baseUrl: string } | null {
  const row = queryOne(
    'SELECT api_key_enc, base_url FROM provider_configs WHERE id = ? AND user_id = ? AND enabled = 1',
    [providerId, userId]
  );

  if (row) {
    const apiKey = row.api_key_enc ? decryptApiKey(row.api_key_enc) : '';
    const baseUrl = (row.base_url as string) || '';
    return { apiKey, baseUrl };
  }

  if (providerId === 'ollama') {
    return { apiKey: '', baseUrl: 'http://127.0.0.1:11434' };
  }

  return null;
}

export function chatRoutes(): Router {
  const router = Router();
  router.use(authMiddleware);

  // POST /api/chat/send — 发送消息（SSE 流式返回）
  router.post('/send', async (req: Request, res: Response) => {
    const userId = getUserId(req);
    const { providerId, modelId, messages, systemPrompt, temperature, maxTokens, conversationId } = req.body;

    // 设置 SSE 响应头
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no',  // 禁用 nginx 缓冲
    });

    const sendChunk = (chunk: any): void => {
      res.write(`data: ${JSON.stringify(chunk)}\n\n`);
    };

    const abortController = new AbortController();
    const requestId = uuidv4();
    activeRequests.set(requestId, abortController);

    // 当客户端断开时自动中止
    req.on('close', () => {
      abortController.abort();
      activeRequests.delete(requestId);
    });

    try {
      // 加载 API Key
      const providerConfig = loadProviderConfig(providerId, userId!);

      if (!providerConfig) {
        sendChunk({ type: 'error', error: { message: `提供商 "${providerId}" 未配置或未启用。请在设置中配置 API Key。`, code: 'NO_API_KEY' } });
        res.end();
        return;
      }

      if (!providerConfig.apiKey && providerId !== 'ollama') {
        sendChunk({ type: 'error', error: { message: `提供商 "${providerId}" 的 API Key 未配置。`, code: 'NO_API_KEY' } });
        res.end();
        return;
      }

      // 上下文裁剪
      const trimmedMessages = trimMessages(messages);
      logger.info(`Web 聊天: provider=${providerId}, model=${modelId}, msgs=${trimmedMessages.length}`);

      // 调用模型适配器
      const stream = modelRouter.chat({
        providerId,
        modelId,
        apiKey: providerConfig.apiKey,
        baseUrl: providerConfig.baseUrl,
        messages: trimmedMessages,
        systemPrompt,
        temperature,
        maxTokens,
        signal: abortController.signal,
      });

      let fullContent = '';
      let thinkingContent = '';

      for await (const chunk of stream) {
        if (abortController.signal.aborted) break;

        if (chunk.textDelta) fullContent += chunk.textDelta;
        if (chunk.thinkingDelta) thinkingContent += chunk.thinkingDelta;

        sendChunk(chunk);

        if (chunk.type === 'done' || chunk.type === 'error') break;
      }

      // 流结束后保存消息
      if (fullContent || thinkingContent) {
        let convId = conversationId;
        const now = Math.floor(Date.now() / 1000);
        const batch: Array<{ sql: string; params: any[] }> = [];

        if (!convId) {
          // 新对话
          const title = (trimmedMessages[trimmedMessages.length - 1]?.content?.slice(0, 50) || '新对话') as string;
          convId = uuidv4();
          batch.push({
            sql: 'INSERT INTO conversations (id, user_id, title, model_id, provider_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
            params: [convId, userId!, title, modelId, providerId, now, now],
          });

          for (const msg of trimmedMessages) {
            batch.push({
              sql: 'INSERT INTO messages (id, conversation_id, role, content, created_at) VALUES (?, ?, ?, ?, ?)',
              params: [uuidv4(), convId, msg.role, typeof msg.content === 'string' ? msg.content : JSON.stringify(msg.content), now],
            });
          }
        } else {
          // 已有对话：只保存最后一条用户消息
          const lastUserMsg = [...trimmedMessages].reverse().find((m: any) => m.role === 'user');
          if (lastUserMsg) {
            batch.push({
              sql: 'INSERT INTO messages (id, conversation_id, role, content, created_at) VALUES (?, ?, ?, ?, ?)',
              params: [uuidv4(), convId, 'user', typeof lastUserMsg.content === 'string' ? lastUserMsg.content : JSON.stringify(lastUserMsg.content), now],
            });
          }
        }

        // 助手回复
        const content = thinkingContent
          ? `[思考过程]\n${thinkingContent}\n\n${fullContent}`
          : fullContent;
        batch.push({
          sql: 'INSERT INTO messages (id, conversation_id, role, content, created_at) VALUES (?, ?, ?, ?, ?)',
          params: [uuidv4(), convId!, 'assistant', content, now],
        });

        // 更新对话元信息
        const addedCount = batch.filter(s => s.sql.includes('INSERT INTO messages')).length;
        batch.push({
          sql: 'UPDATE conversations SET updated_at = ?, message_count = message_count + ? WHERE id = ?',
          params: [now, addedCount, convId!],
        });

        executeBatch(batch);
      }
    } catch (error: any) {
      logger.error('聊天请求失败', error);
      try {
        sendChunk({ type: 'error', error: { message: error.message || '请求失败', code: 'CHAT_ERROR' } });
      } catch {}
    } finally {
      activeRequests.delete(requestId);
      res.end();
    }
  });

  // POST /api/chat/stop — 停止生成
  router.post('/stop', (_req: Request, res: Response) => {
    for (const [, controller] of activeRequests) {
      controller.abort();
    }
    activeRequests.clear();
    res.json({ ok: true });
  });

  return router;
}
