// 登录/注册页面 — 支持 Web 和桌面端，验证码 + 记住密码
import React, { useState, useEffect, useCallback } from 'react';
import { Button, Input, Card, Typography, message, Space, Tabs, Checkbox } from 'antd';
import { RobotOutlined, UserOutlined, LockOutlined, SafetyCertificateOutlined, ReloadOutlined } from '@ant-design/icons';

const { Title, Text } = Typography;
const isElectron = !!(window as any).electronAPI;

interface LoginPageProps {
  onLogin: (user: { id: number; username: string; role: string }) => void;
}

// 简单的本地加密存储（记住密码用）
function obfuscate(text: string): string {
  return btoa(text.split('').map((c, i) => String.fromCharCode(c.charCodeAt(0) ^ (i % 7 + 1))).join(''));
}
function deobfuscate(text: string): string {
  try {
    return atob(text).split('').map((c, i) => String.fromCharCode(c.charCodeAt(0) ^ (i % 7 + 1))).join('');
  } catch { return ''; }
}

function getRemembered(): { username: string; password: string } | null {
  try {
    const raw = localStorage.getItem('remembered_login');
    if (!raw) return null;
    const data = JSON.parse(raw);
    return { username: deobfuscate(data.u), password: deobfuscate(data.p) };
  } catch { return null; }
}

function saveRemembered(username: string, password: string): void {
  localStorage.setItem('remembered_login', JSON.stringify({
    u: obfuscate(username),
    p: obfuscate(password),
  }));
}

function clearRemembered(): void {
  localStorage.removeItem('remembered_login');
}

export function LoginPage({ onLogin }: LoginPageProps) {
  const [tab, setTab] = useState<'login' | 'register'>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(false);
  const [loading, setLoading] = useState(false);

  // 验证码
  const [captchaKey, setCaptchaKey] = useState('');
  const [captchaSvg, setCaptchaSvg] = useState('');
  const [captchaCode, setCaptchaCode] = useState('');

  // 加载记住的密码
  useEffect(() => {
    const saved = getRemembered();
    if (saved) {
      setUsername(saved.username);
      setPassword(saved.password);
      setRemember(true);
    }
  }, []);

  // 刷新验证码
  const refreshCaptcha = useCallback(async () => {
    try {
      const res = await fetch('/api/captcha');
      const data = await res.json();
      setCaptchaKey(data.key);
      setCaptchaSvg(data.svg);
      setCaptchaCode('');
    } catch { /* 桌面端不需要验证码 */ }
  }, []);

  useEffect(() => {
    if (!isElectron) refreshCaptcha();
  }, [tab, refreshCaptcha]);

  const handleSubmit = async () => {
    if (!username.trim() || !password.trim()) {
      message.warning('请填写用户名和密码');
      return;
    }
    if (!isElectron && !captchaCode.trim()) {
      message.warning('请输入验证码');
      return;
    }

    setLoading(true);
    try {
      const endpoint = tab === 'login' ? '/api/auth/login' : '/api/auth/register';

      if (isElectron) {
        // 桌面版通过 IPC
        const result = tab === 'login'
          ? await (window as any).electronAPI.authLogin({ username: username.trim(), password: password.trim() })
          : await (window as any).electronAPI.authRegister({ username: username.trim(), password: password.trim() });
        if (result.ok && result.user) {
          if (remember) saveRemembered(username, password); else clearRemembered();
          localStorage.setItem('desktop_user', JSON.stringify(result.user));
          message.success(tab === 'login' ? '登录成功' : '注册成功');
          setTimeout(() => onLogin(result.user), 500);
        } else {
          message.error(result.error || '操作失败');
          refreshCaptcha();
        }
      } else {
        // Web 版 HTTP
        const res = await fetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            username: username.trim(),
            password: password.trim(),
            captchaKey,
            captchaCode: captchaCode.trim(),
          }),
        });
        const data = await res.json();
        if (res.ok && data.token) {
          if (remember) saveRemembered(username, password); else clearRemembered();
          localStorage.setItem('auth_token', data.token);
          localStorage.setItem('auth_user', JSON.stringify(data.user));
          message.success(tab === 'login' ? '登录成功' : '注册成功');
          setTimeout(() => onLogin(data.user), 500);
        } else {
          message.error(data.error || '操作失败');
          refreshCaptcha();
          setCaptchaCode('');
        }
      }
    } catch {
      message.error(isElectron ? '操作失败' : '连接服务器失败');
      refreshCaptcha();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      height: '100vh', width: '100vw',
      background: isElectron
        ? 'linear-gradient(135deg, rgba(22,119,255,0.03) 0%, rgba(114,46,209,0.03) 100%)'
        : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    }}>
      <Card
        style={{
          width: 420, borderRadius: 20,
          boxShadow: isElectron ? '0 8px 32px rgba(0,0,0,0.08)' : '0 20px 60px rgba(0,0,0,0.2)',
          textAlign: 'center',
        }}
        styles={{ body: { padding: '32px 28px' } }}
      >
        <div style={{ marginBottom: 20 }}>
          <div style={{
            width: 56, height: 56, borderRadius: 16, margin: '0 auto 12px',
            background: 'linear-gradient(135deg, #1677ff, #722ed1)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 6px 20px rgba(22,119,255,0.2)',
          }}>
            <RobotOutlined style={{ color: '#fff', fontSize: 28 }} />
          </div>
          <Title level={3} style={{ margin: 0 }}>小小榆</Title>
          <Text type="secondary">
            {isElectron ? '多模型 AI 桌面助手' : '多模型 AI 助手 · Web 版'}
          </Text>
        </div>

        <Tabs
          activeKey={tab}
          onChange={(k) => { setTab(k as 'login' | 'register'); setCaptchaCode(''); if (!isElectron) refreshCaptcha(); }}
          centered size="small"
          items={[
            { key: 'login', label: '登录' },
            { key: 'register', label: '注册' },
          ]}
          style={{ marginBottom: 10 }}
        />

        <Space direction="vertical" style={{ width: '100%' }} size="small">
          <Input
            prefix={<UserOutlined style={{ color: '#bbb' }} />}
            placeholder="用户名"
            value={username}
            onChange={e => setUsername(e.target.value)}
            size="large" style={{ borderRadius: 12 }}
          />
          <Input.Password
            prefix={<LockOutlined style={{ color: '#bbb' }} />}
            placeholder="密码"
            value={password}
            onChange={e => setPassword(e.target.value)}
            onPressEnter={handleSubmit}
            size="large" style={{ borderRadius: 12 }}
          />

          {/* 验证码（仅 Web 端） */}
          {!isElectron && (
            <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
              <Input
                prefix={<SafetyCertificateOutlined style={{ color: '#bbb' }} />}
                placeholder="数学题答案（点击图片刷新）"
                value={captchaCode}
                onChange={e => setCaptchaCode(e.target.value)}
                onPressEnter={handleSubmit}
                size="large"
                style={{ borderRadius: 12, flex: 1 }}
              />
              <div
                onClick={refreshCaptcha}
                title="看不清？点击刷新"
                style={{ cursor: 'pointer', flexShrink: 0, borderRadius: 10, overflow: 'hidden', border: '1px solid #d9d9d9', height: 42, display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f0f2f5', padding: 2 }}
              >
                {captchaSvg ? (
                  <div dangerouslySetInnerHTML={{ __html: captchaSvg }} style={{ lineHeight: 0 }} />
                ) : (
                  <Text style={{ fontSize: 11, color: '#999' }}>点击加载</Text>
                )}
              </div>
            </div>
          )}

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Checkbox checked={remember} onChange={e => setRemember(e.target.checked)}>
              <Text style={{ fontSize: 12 }}>记住密码</Text>
            </Checkbox>
          </div>

          <Button type="primary" block size="large" loading={loading}
            onClick={handleSubmit}
            style={{ borderRadius: 12, height: 44, fontSize: 16 }}>
            {tab === 'login' ? '登录' : '注册'}
          </Button>
        </Space>

        <div style={{ marginTop: 14 }}>
          <Text type="secondary" style={{ fontSize: 11 }}>
            {isElectron && '默认管理员: admin / admin123'}
            {!isElectron && (
              tab === 'login' ? '没有账号？点击「注册」创建' : '已有账号？点击「登录」'
            )}
          </Text>
        </div>
      </Card>
    </div>
  );
}
