// 发布公告组件 - 登录后弹出
import React, { useState, useEffect } from 'react';
import { Modal, Typography, Tag, Space, Timeline } from 'antd';
import { RocketOutlined, BugOutlined, StarFilled, LockOutlined, CloudServerOutlined } from '@ant-design/icons';

const { Title, Text, Paragraph } = Typography;

const CHANGELOG = [
  { version: 'v2.0.0', date: '2026-07-09', type: 'major', items: [
    { icon: <LockOutlined style={{ color: '#722ed1' }} />, text: '全新多用户登录注册系统 — 每人独立账号，数据完全隔离' },
    { icon: <CloudServerOutlined style={{ color: '#1677ff' }} />, text: 'Web 服务器部署 — 局域网/公网均可访问，手机平板全支持' },
    { icon: <StarFilled style={{ color: '#faad14' }} />, text: '桌面版同步升级 — 应用内同样需登录，安全性全面提升' },
  ]},
  { version: 'v1.5.0', date: '2026-07-09', type: 'feature', items: [
    { icon: <RocketOutlined style={{ color: '#52c41a' }} />, text: '性能大优化 — 流式响应不卡死，数据库批量写入，React.memo 防重渲染' },
    { icon: <BugOutlined style={{ color: '#ff4d4f' }} />, text: '修复窗口无法打开/卡死问题 — 单实例锁机制重写，幽灵锁自动清理' },
    { icon: <RocketOutlined style={{ color: '#1677ff' }} />, text: 'Web 端代码分割 + Gzip 压缩 — 首屏加载体积减少 70%' },
    { icon: <CloudServerOutlined style={{ color: '#1677ff' }} />, text: '内建下载桌面版 + 导入桌面配置 — Web 页面一键操作' },
  ]},
  { version: 'v1.4.0', date: '2026-07-08', type: 'feature', items: [
    { icon: <StarFilled style={{ color: '#52c41a' }} />, text: '支持 9 大模型提供商 — Claude / OpenAI / DeepSeek / Gemini / GLM / 通义千问 / Kimi / 文心一言 / Ollama' },
    { icon: <RocketOutlined style={{ color: '#722ed1' }} />, text: '技能系统 — 28+ 内置技能，聊天框输入指令即可安装' },
    { icon: <StarFilled style={{ color: '#faad14' }} />, text: 'Windows 安装包 + 自动更新 + 系统托盘 + 全局快捷键' },
  ]},
];

export function Announcement() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // 检查是否已看过
    const seen = localStorage.getItem('announcement_seen_v2');
    if (!seen) {
      setVisible(true);
    }
  }, []);

  const handleClose = () => {
    localStorage.setItem('announcement_seen_v2', '1');
    setVisible(false);
  };

  return (
    <Modal
      open={visible}
      onCancel={handleClose}
      footer={null}
      width={600}
      centered
      closable
      title={null}
    >
      <div style={{ textAlign: 'center', marginBottom: 24 }}>
        <div style={{
          width: 56, height: 56, borderRadius: 16, margin: '0 auto 12px',
          background: 'linear-gradient(135deg, #1677ff, #722ed1, #f5222d)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 8px 24px rgba(22,119,255,0.2)',
        }}>
          <RocketOutlined style={{ color: '#fff', fontSize: 28 }} />
        </div>
        <Title level={3} style={{ margin: 0 }}>小小榆 更新日志</Title>
        <Text type="secondary">重大版本升级，请仔细阅读以下内容</Text>
      </div>

      {CHANGELOG.map((release) => (
        <div key={release.version} style={{ marginBottom: 20 }}>
          <Space style={{ marginBottom: 6 }}>
            <Text strong style={{ fontSize: 16 }}>{release.version}</Text>
            <Tag color={release.type === 'major' ? 'red' : 'blue'}>
              {release.type === 'major' ? '重大更新' : '功能更新'}
            </Tag>
            <Text type="secondary" style={{ fontSize: 12 }}>{release.date}</Text>
          </Space>

          <Timeline
            items={release.items.map((item, i) => ({
              dot: item.icon,
              children: <Text style={{ fontSize: 13 }}>{item.text}</Text>,
              key: i,
            }))}
          />
        </div>
      ))}

      <div style={{ textAlign: 'center', marginTop: 8 }}>
        <Text type="secondary" style={{ fontSize: 11 }}>
          桌面版下载和 Web 访问地址请查看首页
        </Text>
      </div>
    </Modal>
  );
}
