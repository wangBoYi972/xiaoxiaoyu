import api from '../../../api';
import React, { useState, useEffect } from 'react';
import { Layout, Modal, Button, Progress, Typography, Space, notification, Card, Empty, Badge, Tag } from 'antd';
import { CloudDownloadOutlined, BellOutlined, SoundOutlined, PushpinOutlined, BulbOutlined, RightOutlined } from '@ant-design/icons';
import { TitleBar } from './TitleBar';
import { Sidebar } from './Sidebar';
import { ChatView } from '../chat/ChatView';
import { WelcomeView } from '../chat/WelcomeView';
import { useChatStore } from '../../stores/chat-store';
import { SettingsDrawer } from '../settings/SettingsDrawer';
import { useSettingsStore } from '../../stores/settings-store';
import { Announcement } from './Announcement';

const { Sider, Content } = Layout;
const { Text, Paragraph, Title } = Typography;

interface AnnounceItem {
  id: string; title: string; content: string; level: 'info' | 'warning' | 'important'; time?: string;
}

const CHANGELOG: AnnounceItem[] = [
  { id:'v1.5-skills', title:'技能市场正式上线', level:'important', time:'v1.5',
    content:'🏪 技能市场\n\n直接在主页浏览和安装各种AI技能，28个技能覆盖编程、写作、创意、分析、生活等各个领域。\n\n📥 三种安装方式\n• 主页点击"安装"按钮\n• 聊天框输入"技能列表"查看全部\n• 输入"安装技能 XXX"一键安装\n\n🌐 远程仓库自动同步\n启动时自动拉取最新技能目录，社区技能持续更新。' },
  { id:'v1.5-winctrl', title:'窗口控制创意升级', level:'info', time:'v1.5',
    content:'🎨 窗口按钮重新设计\n\n• 最小化 — 悬停变为橙色\n• 最大化 — 悬停变为绿色\n• 关闭 — 悬停变为红色\n\n每个按钮独立圆角设计，悬停有微动画和颜色反馈，告别单调的灰色图标。' },
  { id:'v1.5-dark', title:'深色主题全面覆盖', level:'info', time:'v1.5',
    content:'🌙 暗色模式完美适配\n\n• 所有玻璃组件暗色重绘\n• 弹窗、下拉框、消息提示全部适配\n• 代码块、引用块、表格暗色优化\n• 滚动条暗色样式\n• 设置卡片暗色背景\n\n跟随系统自动切换或手动选择。' },
  { id:'v1.5-home', title:'首页全新设计', level:'info', time:'v1.5',
    content:'🏠 首页焕然一新\n\n• Logo渐变图标 + 品牌名\n• 轮换问候语\n• 功能亮点标签展示\n• 免费模型三卡片快速切换\n• 更多模型入口\n• Ollama未安装友好引导\n\n整体字号放大，间距优化，阅读更舒适。' },
  { id:'v1.5-chatbar', title:'对话信息栏', level:'info', time:'v1.5',
    content:'💬 聊天页面新增顶部信息栏\n\n• 显示当前对话标题\n• 显示正在使用的模型名称\n• 显示消息计数\n• 渐变色AI图标\n\n让对话更有上下文，不再迷失在消息中。' },
  { id:'v1.5-model', title:'默认免费模型优化', level:'info', time:'v1.5',
    content:'🆓 零配置免费使用\n\n• Ollama 自动检测，可用即启用\n• 智谱 GLM-4-Flash 完全免费\n• Gemini 免费额度\n\n无需填写任何 API Key 即可体验 AI 对话（需自行安装配置对应服务）。' },
];

export function AppLayout() {
  const { messages } = useChatStore();
  const { settingsOpen, toggleSettings, bgImage, bgOpacity } = useSettingsStore();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [updateModal, setUpdateModal] = useState(false);
  const [updateInfo, setUpdateInfo] = useState<any>(null);
  const [updateProgress, setUpdateProgress] = useState<any>(null);
  const [updating, setUpdating] = useState(false);
  const [announceModal, setAnnounceModal] = useState(false);
  const [selectedAnnounce, setSelectedAnnounce] = useState<AnnounceItem | null>(null);
  const [announceList, setAnnounceList] = useState<AnnounceItem[]>(CHANGELOG);

  useEffect(() => {
    const offA = api.onAnnouncement((ann: any) => {
      const exists = announceList.find((a) => a.id === ann.id);
      if (!exists) {
        const item: AnnounceItem = { id: ann.id, title: ann.title, content: ann.content, level: ann.level, time: '' };
        setAnnounceList((prev) => [item, ...prev]);
        setSelectedAnnounce(item);
        setAnnounceModal(true);
      }
    });
    const off1 = api.onUpdateAvailable((info) => { setUpdateInfo(info); setUpdateModal(true); });
    const off2 = api.onUpdateProgress((p) => { setUpdateProgress(p); if (p.stage === 'done') { setUpdateModal(false); setUpdating(false); } });
    const off3 = api.onUpdateError((err) => { notification.error({ message: '更新失败', description: err.message }); setUpdating(false); });
    return () => { offA(); off1(); off2(); off3(); };
  }, []);

  const handleShowAnnouncements = () => {
    setSelectedAnnounce(null);
    setAnnounceModal(true);
  };

  const handleAnnounceClose = () => {
    setAnnounceModal(false);
    setSelectedAnnounce(null);
  };

  const handleUpdate = async () => { if (!updateInfo?.downloadUrl) return; setUpdating(true); setUpdateProgress({ stage: 'downloading', percent: 0 }); try { await api.installUpdate(updateInfo.downloadUrl); } catch { setUpdating(false); } };

  const hasMessages = messages.length > 0;

  // 背景样式
  const bgStyle: React.CSSProperties = bgImage ? {
    backgroundImage: `url(${bgImage})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',
    backgroundAttachment: 'fixed',
  } : {
    background: 'var(--bg-gradient)',
    backgroundSize: '400% 400%',
  };

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', ...bgStyle, animation: bgImage ? 'none' : 'gradientShift 20s ease infinite', position: 'relative' }}>
      {/* 半透明遮罩层（自定义背景时） */}
      {bgImage && (
        <div style={{ position: 'absolute', inset: 0, background: `rgba(255,255,255,${1 - bgOpacity})`, zIndex: 0, pointerEvents: 'none' }} />
      )}

      {!bgImage && <style>{`@keyframes gradientShift { 0% {background-position:0% 50%} 50% {background-position:100% 50%} 100% {background-position:0% 50%} }`}</style>}

      <div style={{ position: 'relative', zIndex: 1, display: 'flex', flexDirection: 'column', height: '100%' }}>
        <TitleBar onSettingsClick={toggleSettings} sidebarCollapsed={sidebarCollapsed} onToggleSidebar={() => setSidebarCollapsed(!sidebarCollapsed)} onAnnouncementClick={handleShowAnnouncements} />
        <Layout style={{ flex: 1, overflow: 'hidden', background: 'transparent' }}>
          <Sider width={260} collapsedWidth={0} collapsed={sidebarCollapsed} style={{ background: 'transparent' }} trigger={null}>
            <Sidebar onCollapse={() => setSidebarCollapsed(true)} />
          </Sider>
          <Content style={{ display: 'flex', flexDirection: 'column', background: 'transparent' }}>
            {hasMessages ? <ChatView /> : <WelcomeView />}
          </Content>
        </Layout>
        <SettingsDrawer open={settingsOpen} onClose={toggleSettings} />

        {/* 发布公告（首次登录弹出） */}
        <Announcement />
      </div>

      {/* ====== 公告浏览弹窗 ====== */}
      <Modal
        title={
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <BellOutlined style={{ fontSize: 20, color: '#1677ff' }} />
            <span style={{ fontWeight: 700, fontSize: 17 }}>
              {selectedAnnounce ? selectedAnnounce.title : '更新公告'}
            </span>
            {!selectedAnnounce && <Badge count={announceList.length} style={{ backgroundColor: '#1677ff' }} />}
          </div>
        }
        open={announceModal}
        onCancel={handleAnnounceClose}
        width={selectedAnnounce ? 540 : 660}
        footer={selectedAnnounce
          ? [<Button key="back" onClick={() => setSelectedAnnounce(null)} style={{ borderRadius: 10 }}>← 返回列表</Button>,
             <Button key="ok" type="primary" onClick={handleAnnounceClose} style={{ borderRadius: 10 }}>我知道了</Button>]
          : [<Button key="close" type="primary" onClick={handleAnnounceClose} style={{ borderRadius: 10 }}>关闭</Button>]
        }
      >
        {selectedAnnounce ? (
          /* ====== 单个公告详情 ====== */
          <div style={{ padding: '8px 0' }}>
            <Space style={{ marginBottom: 16 }}>
              <Tag color={selectedAnnounce.level === 'important' ? 'red' : selectedAnnounce.level === 'warning' ? 'orange' : 'blue'}
                style={{ borderRadius: 8, fontSize: 12, padding: '2px 10px' }}>
                {selectedAnnounce.level === 'important' ? '  重要' : selectedAnnounce.level === 'warning' ? '⚠️ 提醒' : '  资讯'}
              </Tag>
              {selectedAnnounce.time && <Text type="secondary" style={{ fontSize: 12 }}>{selectedAnnounce.time}</Text>}
            </Space>
            <Paragraph style={{ whiteSpace: 'pre-wrap', fontSize: 14, lineHeight: 1.9, color: 'rgba(0,0,0,0.75)' }}>
              {selectedAnnounce.content}
            </Paragraph>
          </div>
        ) : (
          /* ====== 公告卡片列表 ====== */
          <div style={{ maxHeight: 460, overflow: 'auto', padding: '4px 0' }}>
            <Paragraph type="secondary" style={{ fontSize: 12, marginBottom: 14 }}>
              点击卡片查看详细内容。更新说明涵盖 v1.5 所有改动。
            </Paragraph>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12 }}>
              {announceList.map((item) => {
                const colors: Record<string, { bg: string; border: string; icon: React.ReactNode }> = {
                  important: { bg: 'rgba(255,77,79,0.04)', border: 'rgba(255,77,79,0.2)', icon: <PushpinOutlined style={{ color: '#ff4d4f' }} /> },
                  warning: { bg: 'rgba(250,173,20,0.04)', border: 'rgba(250,173,20,0.2)', icon: <SoundOutlined style={{ color: '#faad14' }} /> },
                  info: { bg: 'rgba(22,119,255,0.03)', border: 'rgba(22,119,255,0.12)', icon: <BulbOutlined style={{ color: '#1677ff' }} /> },
                };
                const c = colors[item.level] || colors.info;
                return (
                  <Card key={item.id} size="small" hoverable
                    onClick={() => setSelectedAnnounce(item)}
                    style={{
                      borderRadius: 14, cursor: 'pointer',
                      background: c.bg, border: `1px solid ${c.border}`,
                      transition: 'all 0.2s ease',
                    }}
                    styles={{ body: { padding: '14px 16px' } }}
                  >
                    <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                      <div style={{ marginTop: 2, flexShrink: 0 }}>{c.icon}</div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <Text strong style={{ fontSize: 14, display: 'block', marginBottom: 4 }}>{item.title}</Text>
                        <Text type="secondary" style={{ fontSize: 11, lineHeight: 1.5 }} ellipsis={{ rows: 2 }}>
                          {item.content.split('\n').filter((l: string) => !l.startsWith('•') && !l.startsWith('1.') && !l.startsWith('2.') && !l.startsWith('3.') && l.trim()).slice(0, 2).join(' ')}
                        </Text>
                        <div style={{ marginTop: 8, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <Tag color={item.level === 'important' ? 'red' : 'blue'} style={{ borderRadius: 6, fontSize: 10, padding: '0 6px' }}>
                            {item.level === 'important' ? '重要' : '更新'}
                          </Tag>
                          <RightOutlined style={{ fontSize: 10, color: 'rgba(0,0,0,0.25)' }} />
                        </div>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
            {announceList.length === 0 && <Empty description="暂无公告" />}
          </div>
        )}
      </Modal>

      {/* 更新弹窗 */}
      <Modal title={<><CloudDownloadOutlined /> 发现新版本</>} open={updateModal} onCancel={() => setUpdateModal(false)}
        footer={updating ? null : [<Button key="cancel" onClick={() => setUpdateModal(false)}>稍后提醒</Button>, <Button key="update" type="primary" onClick={handleUpdate} icon={<CloudDownloadOutlined />}>立即更新</Button>]} closable={!updating}>
        {updateInfo && !updating && (
          <div>
            <Space direction="vertical" style={{ width: '100%' }}>
              <Text>当前版本: <Text type="secondary">{updateInfo.currentVersion}</Text></Text>
              <Text>最新版本: <Text strong style={{ color: '#1677ff', fontSize: 16 }}>{updateInfo.version}</Text></Text>
              {updateInfo.releaseNotes && <Paragraph style={{ background: 'rgba(0,0,0,0.03)', padding: 12, borderRadius: 8, marginTop: 8, maxHeight: 200, overflow: 'auto', whiteSpace: 'pre-wrap', fontSize: 13 }}>{updateInfo.releaseNotes}</Paragraph>}
            </Space>
          </div>
        )}
        {updating && (
          <div style={{ textAlign: 'center', padding: '20px 0' }}>
            <Progress type="circle" percent={updateProgress?.percent || 0} size={80} />
            <Paragraph style={{ marginTop: 12 }}>{updateProgress?.stage === 'downloading' ? '正在下载更新...' : updateProgress?.stage === 'extracting' ? '正在解压...' : updateProgress?.stage === 'installing' ? '正在安装...' : '更新中...'}</Paragraph>
          </div>
        )}
      </Modal>
    </div>
  );
}
