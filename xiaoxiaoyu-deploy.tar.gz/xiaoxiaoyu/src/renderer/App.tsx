import React, { useEffect, useState } from 'react';
import { ConfigProvider, theme, App as AntApp } from 'antd';
import zhCN from 'antd/locale/zh_CN';
import { HashRouter, Routes, Route } from 'react-router-dom';
import { AppLayout } from './components/layout/AppLayout';
import { LoginPage } from './components/auth/LoginPage';
import { useSettingsStore } from './stores/settings-store';
import { useModelStore } from './stores/model-store';

const isElectron = !!(window as any).electronAPI;

interface AuthUser { id: number; username: string; role: string; }

function getStoredUser(): AuthUser | null {
  try {
    const raw = localStorage.getItem(isElectron ? 'desktop_user' : 'auth_user');
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

export function App() {
  const { theme: themeMode } = useSettingsStore();
  const { loadProviders } = useModelStore();
  const [authUser, setAuthUser] = useState<AuthUser | null>(getStoredUser());

  useEffect(() => {
    if (authUser) loadProviders();
  }, [authUser, loadProviders]);

  const handleLogin = (user: AuthUser) => {
    const key = isElectron ? 'desktop_user' : 'auth_user';
    localStorage.setItem(key, JSON.stringify(user));
    setAuthUser(user);
  };

  // 监听系统主题变化
  const [systemIsDark, setSystemIsDark] = useState(
    () => window.matchMedia?.('(prefers-color-scheme: dark)').matches ?? false
  );

  useEffect(() => {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = (e: MediaQueryListEvent) => setSystemIsDark(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  const isDark = themeMode === 'dark' || (themeMode === 'system' && systemIsDark);
  useEffect(() => { document.body.classList.toggle('dark-theme', isDark); }, [isDark]);

  const algorithm = isDark ? [theme.darkAlgorithm] : [theme.defaultAlgorithm];

  // 未登录 → 显示登录/注册页
  if (!authUser) {
    return (
      <ConfigProvider locale={zhCN} theme={{ algorithm, token: { colorPrimary: '#1677ff', borderRadius: 8 } }}>
        <AntApp>
          <LoginPage onLogin={handleLogin} />
        </AntApp>
      </ConfigProvider>
    );
  }

  return (
    <ConfigProvider
      locale={zhCN}
      theme={{
        algorithm,
        token: {
          colorPrimary: '#1677ff',
          borderRadius: 8,
          fontSize: 15,
          fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'PingFang SC', 'Microsoft YaHei', sans-serif",
        },
      }}
    >
      <AntApp>
        <HashRouter>
          <Routes>
            <Route path="/*" element={<AppLayout />} />
          </Routes>
        </HashRouter>
      </AntApp>
    </ConfigProvider>
  );
}
