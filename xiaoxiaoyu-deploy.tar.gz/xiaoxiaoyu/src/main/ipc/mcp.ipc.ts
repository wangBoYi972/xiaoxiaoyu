import { ipcMain } from 'electron';
import { MCPManager, MCPServerConfig } from '../mcp/mcp-client';
import { logger } from '../utils/logger';
import fs from 'fs';
import path from 'path';
import { app } from 'electron';

const mcpManager = new MCPManager();

export function registerMcpHandlers(): void {
  // 列出所有 MCP 服务器
  ipcMain.handle('mcp:list-servers', async () => {
    const config = loadMcpConfig();
    const servers = Object.entries(config.mcpServers || {}).map(([name, def]) => ({
      id: name,
      name,
      command: def.command,
      args: def.args || [],
      env: def.env,
      disabled: def.disabled || false,
      status: mcpManager.getServerStatus(name),
    }));
    return servers;
  });

  // 添加 MCP 服务器
  ipcMain.handle('mcp:add-server', async (_event, server: MCPServerConfig) => {
    // 保存到配置文件
    const config = loadMcpConfig();
    config.mcpServers[server.name] = {
      command: server.command,
      args: server.args,
      env: server.env,
      disabled: server.disabled || false,
    };
    saveMcpConfig(config);

    // 启动服务器
    await mcpManager.addServer(server);
    logger.info(`MCP 服务器已添加: ${server.name}`);
  });

  // 移除 MCP 服务器
  ipcMain.handle('mcp:remove-server', async (_event, id: string) => {
    const config = loadMcpConfig();
    delete config.mcpServers[id];
    saveMcpConfig(config);

    await mcpManager.removeServer(id);
    logger.info(`MCP 服务器已移除: ${id}`);
  });

  // 开关 MCP 服务器
  ipcMain.handle('mcp:toggle-server', async (_event, id: string, enabled: boolean) => {
    const config = loadMcpConfig();
    if (config.mcpServers[id]) {
      config.mcpServers[id].disabled = !enabled;
      saveMcpConfig(config);
    }

    if (enabled) {
      const def = config.mcpServers[id];
      await mcpManager.addServer({
        id,
        name: id,
        command: def.command,
        args: def.args || [],
        env: def.env,
        disabled: false,
      });
    } else {
      await mcpManager.removeServer(id);
    }
  });

  // 列出所有工具
  ipcMain.handle('mcp:list-tools', async () => {
    return mcpManager.getAllTools();
  });

  // 调用工具
  ipcMain.handle('mcp:call-tool', async (_event, serverId: string, toolName: string, args: Record<string, unknown>) => {
    return mcpManager.callTool(serverId, toolName, args);
  });
}

// 配置文件路径
function getMcpConfigPath(): string {
  const userDataPath = app.getPath('userData');
  return path.join(userDataPath, 'mcp-config.json');
}

interface MCPConfigFile {
  mcpServers: Record<string, {
    command: string;
    args?: string[];
    env?: Record<string, string>;
    disabled?: boolean;
  }>;
}

function loadMcpConfig(): MCPConfigFile {
  try {
    const configPath = getMcpConfigPath();
    if (fs.existsSync(configPath)) {
      const content = fs.readFileSync(configPath, 'utf-8');
      return JSON.parse(content);
    }
  } catch (e) {
    logger.error('读取 MCP 配置文件失败', e as Error);
  }
  return { mcpServers: {} };
}

function saveMcpConfig(config: MCPConfigFile): void {
  try {
    const configPath = getMcpConfigPath();
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf-8');
  } catch (e) {
    logger.error('保存 MCP 配置文件失败', e as Error);
  }
}
