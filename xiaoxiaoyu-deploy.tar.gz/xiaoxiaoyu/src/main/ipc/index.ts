import { ipcMain } from 'electron';
import { registerChatHandlers } from './chat.ipc';
import { registerConversationHandlers } from './conversation.ipc';
import { registerSettingsHandlers } from './settings.ipc';
import { registerFileHandlers } from './file.ipc';
import { registerWindowHandlers } from './window.ipc';
import { registerMcpHandlers } from './mcp.ipc';
import { registerSkillsHandlers } from './skills.ipc';
import { registerAuthHandlers } from './auth.ipc';

export function registerIpcHandlers(): void {
  registerAuthHandlers();
  registerChatHandlers();
  registerConversationHandlers();
  registerSettingsHandlers();
  registerFileHandlers();
  registerWindowHandlers();
  registerMcpHandlers();
  registerSkillsHandlers();
}
