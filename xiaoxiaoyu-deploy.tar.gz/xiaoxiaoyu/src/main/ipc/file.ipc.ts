import { ipcMain, dialog, BrowserWindow } from 'electron';
import * as fs from 'fs';
import path from 'path';

export function registerFileHandlers(): void {
  ipcMain.handle('file:openDialog', async (event, options?: { filters?: Array<{ name: string; extensions: string[] }> }) => {
    const win = BrowserWindow.fromWebContents(event.sender);
    if (!win) return [];

    const result = await dialog.showOpenDialog(win, {
      properties: ['openFile', 'multiSelections'],
      filters: options?.filters || [
        { name: '所有文件', extensions: ['*'] },
        { name: '图片', extensions: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp'] },
        { name: '文档', extensions: ['pdf', 'doc', 'docx', 'txt', 'md'] },
      ],
    });

    return result.canceled ? [] : result.filePaths;
  });

  ipcMain.handle('file:read', async (_event, filePath: string) => {
    const data = fs.readFileSync(filePath);
    const ext = path.extname(filePath).toLowerCase();
    const mimeTypes: Record<string, string> = {
      '.png': 'image/png',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.gif': 'image/gif',
      '.webp': 'image/webp',
      '.bmp': 'image/bmp',
      '.pdf': 'application/pdf',
      '.txt': 'text/plain',
      '.md': 'text/markdown',
    };

    return {
      data: data.toString('base64'),
      mimeType: mimeTypes[ext] || 'application/octet-stream',
      name: path.basename(filePath),
    };
  });
}
