import crypto from 'crypto';
import os from 'os';

// 使用机器信息生成加密密钥
function deriveKey(): Buffer {
  const hostname = os.hostname();
  const username = os.userInfo().username;
  const seed = `${hostname}:${username}:ai-chat-desktop-salt-v1`;
  return crypto.createHash('sha256').update(seed).digest();
}

const ALGORITHM = 'aes-256-gcm';

export function encryptApiKey(plainText: string): string {
  const key = deriveKey();
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
  const encrypted = Buffer.concat([cipher.update(plainText, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return `${iv.toString('base64')}:${authTag.toString('base64')}:${encrypted.toString('base64')}`;
}

export function decryptApiKey(encryptedText: string): string {
  const key = deriveKey();
  const parts = encryptedText.split(':');
  if (parts.length !== 3) {
    throw new Error('无效的加密格式');
  }
  const iv = Buffer.from(parts[0], 'base64');
  const authTag = Buffer.from(parts[1], 'base64');
  const encrypted = Buffer.from(parts[2], 'base64');
  const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
  decipher.setAuthTag(authTag);
  const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
  return decrypted.toString('utf8');
}
